export default [
    'https://developer.mozilla.org/zh-CN/plus',
    'https://www.iconfont.cn/',
    'https://www.axios-http.cn/docs/intro',
    'http://fanyi.baidu.com/',
    'https://github.com/',
    'https://vuejsexamples.com/',
    'http://echarts.zhangmuchen.top/#/index',
    'http://chartlib.datains.cn',
    'http://datav.jiaminghi.com/guide/',
    'https://echarts.apache.org/zh/index.html',
    'https://gptgo.ai/?hl=zh&utm_source=futurepedia&&utm_medium=marketplace&&utm_campaign=futurepedia',
    'https://momentjs.cn/docs/',
    'https://www.lodashjs.com/',

]